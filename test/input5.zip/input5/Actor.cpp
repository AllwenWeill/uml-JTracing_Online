#include "Actor.h"

int Actor::getActorNum(int a) {
    return a;
}