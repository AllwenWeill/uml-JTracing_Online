
#include "Chef.h"
#include "Actor.h"
class Test {


public:
    int m_num;
    Actor2();
    ~Actor2() {};
    void buyFood(int);
private:
    int getActorNum2();

};


