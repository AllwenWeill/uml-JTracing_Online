#include "Test.h"

void Test::buyFood(int a) {
}